
package com.example.bomberman.entities;

public enum Direction {
    UP, DOWN, LEFT, RIGHT, NONE
}